module.exports = {
  title:
    'DW Case:Best CS:GO case opening site | Drop is better than from Gaben',

  /**
   * @type {Number}
   * @description Limit items per page
   */
  limitPerPage: 20,
  /*
  Token name set by server
  */
  tokenName: 'CSSESSIONID',
  // Using for animation open case
  timeStamp: 9,
}
