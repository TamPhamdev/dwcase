import Vue from 'vue'
import VueKinesis from 'vue-kinesis'

Vue.use(VueKinesis)
