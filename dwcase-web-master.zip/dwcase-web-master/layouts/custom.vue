<template>
  <div class="dark">
    <Nuxt />
  </div>
</template>

<style>
</style>
