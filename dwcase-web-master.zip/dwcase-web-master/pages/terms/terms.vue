<template>

</template>

<script>
  export default {
    name: "Terms and Conditions"
  }
</script>

<style>
</style>
