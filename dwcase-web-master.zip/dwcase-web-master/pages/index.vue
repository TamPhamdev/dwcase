<template>
  <div class="flex flex-wrap">
    <Section
      v-for="(item, index) in cases"
      :key="index"
      :title="item.name"
      class="trending"
    >
      <Case
        v-for="(data, dataIndex) in item.cases"
        :data="data"
        :key="dataIndex"
      />
    </Section>

    <Wrapper>
      <Stat :data="stats" />
    </Wrapper>

  </div>
</template>

<script>
  import { mapActions, mapGetters } from 'vuex'
  import { tokenName } from "@/settings"
  import Stat from "@/layouts/Header/Stat"
  export default {
    name: "Home",
    components: { Stat },

    computed: {
      ...mapGetters({ cases: 'case/getCases', stats: 'stat/getStats' }),
    },

    methods: {
      // ...mapActions('case', ['getAllCases']),
    },

  }
</script>

<style lang="scss" scoped>
  .trending {
    background-image: url('~@/assets/images/trending.jpg');
    background-size: cover;
    background-position: top;
  }
  .battle {
    background-image: url('~@/assets/images/battle_cases.png');
    background-size: cover;
    background-position: top;
  }
</style>
