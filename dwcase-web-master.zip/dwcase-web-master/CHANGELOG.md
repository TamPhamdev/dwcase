# Changelog

All notable changes to this project will be documented in this file.
# v0.1.8

- Customize notification.
- Handle redirect on client.
# v0.1.7

- Fix always redirect 403
# v0.1.6

- Add icon statistics & 403 page.
# v0.1.5
- Handle enable sound setting.
- Fix cannot play sound files wav.
- Fix hide sidebar after change route.
# v0.1.4
- Add items in cases.
# v0.1.3

- Add localization
- Add sound effects & enable skip animations
- Add `Purchase history`.
- Add filter items by status.
- Add `Sell, Accept` items in inventory.
- Add `Top up` page.
- Enhancement redirect URL after login.
- Remove unused dependencies.
# v0.1.2

- Add filter items by status.
# v0.1.1
- Added `Home` page.
- Added `Profile` page.
- Added `Items` `Item Detail` page.
- Added `Case Detail` page.

